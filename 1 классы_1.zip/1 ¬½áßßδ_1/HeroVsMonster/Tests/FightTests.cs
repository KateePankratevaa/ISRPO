﻿using System;
using NUnit.Framework;
using HeroVsMonster.Classes;

namespace HeroVsMonster.Tests
{
    class FightTests
    {
        Monster EvilTroll;
        Monster SuperDragon;
        Hero Vasya;
        Hero BruceLee;

        [SetUp]
        public void Setup()
        {
            Vasya = new Hero("Вася Пупкин", 200, 15);
            BruceLee = new Hero("Брюс Ли", 20000, 75);
            EvilTroll = new Monster("Злой троль", 200, 25);
            SuperDragon = new Monster("Супер дракон", 50000, 200);
        }

        [Test]
        public void Vasya_Attack_Troll()
        {
            Vasya.Attack(EvilTroll);
            int Expected = 185;
            int Actual = EvilTroll.Health;
            Assert.AreEqual(Expected, Actual);
        }

        [Test]
        public void Troll_Punch_Vasya()
        {
            EvilTroll.Punch(Vasya);
            int Expected = 175;
            int Actual = Vasya.Health;
            Assert.AreEqual(Expected, Actual);
        }

        [Test]
        public void Vasya_Vs_Troll_Fight()
        {
            Vasya.Attack(EvilTroll);
            Vasya.Attack(EvilTroll); 
            EvilTroll.Punch(Vasya);
            Vasya.Attack(EvilTroll); 
            EvilTroll.Punch(Vasya);
            int ExpectedTrollHp = 155;
            int ActualTrollHp = EvilTroll.Health;
            int ExpectedVasyaHp = 150;
            int ActualVasyaHp = Vasya.Health;
            Assert.AreEqual(ExpectedTrollHp, ActualTrollHp);
            Assert.AreEqual(ExpectedVasyaHp, ActualVasyaHp);
        }

        [Test]
        public void Troll_Uses_Mega_Punch_on_Vasya()
        {
            EvilTroll.MegaPunch(Vasya);
            int Expected = 75;
            int Actual = Vasya.Health;
            Assert.AreEqual(Expected, Actual);
        }


        [Test]
        public void Vasya_Attack_Troll_With_Sword()
        {
            Weapon Sword = new Weapon(130);
            Vasya.HeroWeapon = Sword;
            Vasya.Attack(EvilTroll);
            int ExpectedTrollHp = 70;
            int ActualTrollHp = EvilTroll.Health;
            Assert.AreEqual(ExpectedTrollHp, ActualTrollHp);
        }

        [Test]
        public void Vasya_Kills_Troll_With_Imba_Sword()
        {
            Weapon ImbaSword8000 = new Weapon(99999);
            Vasya.HeroWeapon = ImbaSword8000;
            Vasya.Attack(EvilTroll);
            Assert.IsTrue(EvilTroll.IsDead);
        }

        [Test]
        public void BruceLee_Hits_And_Drop_a_Weapon()
        {
            Weapon Nunchucks = new Weapon(100);
            BruceLee.HeroWeapon = Nunchucks;
            BruceLee.Attack(EvilTroll);
            BruceLee.HeroWeapon = null;
            BruceLee.Attack(EvilTroll);
            int ExpectedTrollHp = 25;
            int ActualTrollHp = EvilTroll.Health;
            Assert.AreEqual(ExpectedTrollHp, ActualTrollHp);
        }

        [Test]
        public void BruceLee_Hits_And_Take_a_Weapon()
        {
            BruceLee.Attack(EvilTroll);
            Weapon Nunchucks = new Weapon(100);
            BruceLee.HeroWeapon = Nunchucks;
            BruceLee.Attack(EvilTroll);
            int ExpectedTrollHp = 25;
            int ActualTrollHp = EvilTroll.Health;
            Assert.AreEqual(ExpectedTrollHp, ActualTrollHp);
        }

        [Test]
        public void Vasya_Execute_The_FullHp_Dragon()
        {
            Vasya.Execute(SuperDragon);
            int ExpectedDragonHP = 49985;
            int ActualDragonHP = SuperDragon.Health;
            Assert.AreEqual(ExpectedDragonHP, ActualDragonHP);
        }

        [Test]
        public void Vasya_Execute_The_LowHp_Dragon_But_Dragon_Still_Strong()
        {
            Weapon MegaCrossbow = new Weapon(39999);
            Vasya.HeroWeapon = MegaCrossbow;
            Vasya.Attack(SuperDragon);
            Vasya.HeroWeapon = null;
            Vasya.Execute(SuperDragon);
            int ExpectedDragonHP = 9986;
            int ActualDragonHP = SuperDragon.Health;
            Assert.AreEqual(ExpectedDragonHP, ActualDragonHP);
        }

        [Test]
        public void Vasya_Execute_The_LowHp_Dragon_With_20_percent()
        {
            Weapon Warhammer = new Weapon(40000);
            Vasya.HeroWeapon = Warhammer;
            Vasya.Attack(SuperDragon);
            Vasya.HeroWeapon = null;
            Vasya.Execute(SuperDragon);
            int ExpectedDragonHP = 9850;
            int ActualDragonHP = SuperDragon.Health;
            Assert.AreEqual(ExpectedDragonHP, ActualDragonHP);
        }

        [Test]
        public void Vasya_Execute_Dragon_By_Weapon()
        {
            Weapon Warhammer = new Weapon(40000);
            Vasya.HeroWeapon = Warhammer;
            Vasya.Attack(SuperDragon);
            Weapon BigGun = new Weapon(1000);
            Vasya.HeroWeapon = BigGun;
            Vasya.Execute(SuperDragon);
            int ExpectedDragonHP = 0;
            int ActualDragonHP = SuperDragon.Health;
            Assert.AreEqual(ExpectedDragonHP, ActualDragonHP);
        }

        [Test]
        public void Hero_Cant_Attack_After_Death()
        {
            SuperDragon.Punch(Vasya);
            Vasya.Attack(SuperDragon);
            int ExpectedDragonHP = 50000;
            int ActualDragonHP = SuperDragon.Health;
            Assert.AreEqual(ExpectedDragonHP, ActualDragonHP);
        }

        [Test]
        public void Moster_Cant_Attack_After_Death()
        {
            BruceLee.Attack(EvilTroll);
            BruceLee.Attack(EvilTroll);
            BruceLee.Attack(EvilTroll);
            EvilTroll.Punch(BruceLee);
            int ExpectedHP = 20000;
            int ActualHP = BruceLee.Health;
            Assert.AreEqual(ExpectedHP, ActualHP);
        }

        [Test]
        public void Vasya_Wins_Dragon_And_Roar()
        {
            Weapon Fork = new Weapon(1);
            Vasya.HeroWeapon = Fork;
            for (int i = 1; i <= 50000; ++i)
            {
                Vasya.Attack(SuperDragon);
            }

            string Roar = Vasya.Roar();
            Assert.AreEqual(Roar, "УУООООО!!!!");
        }

        [Test]
        public void EvilTroll_Wins_Vasya_And_Roar()
        {
            Vasya.Attack(EvilTroll);
            EvilTroll.Punch(Vasya);
            Vasya.Attack(EvilTroll);
            EvilTroll.Punch(Vasya);
            Vasya.Attack(EvilTroll);
            EvilTroll.Punch(Vasya);
            Vasya.Attack(EvilTroll);
            EvilTroll.Punch(Vasya);

            string Roar = EvilTroll.Roar();
            Assert.AreEqual(Roar, "ЪУЪ!!!");
        }




    }
}
