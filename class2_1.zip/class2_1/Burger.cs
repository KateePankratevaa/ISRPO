﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class2_1
{
    public class Burger : Product
    {
        private List<Option> options = new List<Option>();


        public Burger(decimal basePrice, string Name, string ImagePath)
            : base(basePrice, Name, ImagePath)
        {

        }

        public override decimal GetPrice()
        {
            decimal allPriceOption = 0;
            for (int i = 0; i < options.Count; i++)
            {
                allPriceOption += options[i].Price;
            }
            if (allPriceOption == 0)
            {
                return BasePrice;
            }
            else return BasePrice + allPriceOption;
        }
       
        public void AddOption(Option option)
        {
            options.Add(option);
        }
        public void ClearOptions()
        {
            options.Clear();
        }
    }
}
