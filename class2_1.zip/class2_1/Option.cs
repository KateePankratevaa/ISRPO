﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class2_1
{
    public class Option
    {
        public string Name;
        public decimal Price;

        public Option(string name, decimal price)
        {
            this.Name = name;
            this.Price = price;
        }
    }
}
