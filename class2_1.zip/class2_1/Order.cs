﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class2_1
{
    public class Order
    {
        private List<Product> products = new List<Product>(); //товар (название и цена)
        int Number; //номер заказа
        DateTime OrderTime;

        public Order(int Number)
        {
            this.Number = Number;
            OrderTime = DateTime.Now;
        }
        //сам заказ

        public void AppProduct(Product product)
        {
            products.Add(product);
        }
        public void Clear()
        {
            products.Clear();
        }
        public decimal TotalPrice()
        {
            decimal allPrice = 0;
            for (int i = 0; i < products.Count; i++)
            {
                allPrice += products[i].BasePrice;
            }
            if (allPrice == 0)
            {
                return 0;
            }
            else return allPrice;
        }
        public string GetCheck()
        {
            string check = $"Номер {Number}\nДата: {OrderTime}\n";
            for (int i = 0; i < products.Count; i++)
            {
                check += $"Наименование {products[i].Name} Стоимость: {products[i].BasePrice}\n";
            }
            check += $"\n Стоимость всего заказа равна {TotalPrice().ToString()}";
            return check;
        }
    }
}