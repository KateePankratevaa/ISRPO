﻿using class2_1;
using System;
using System.Xml.Linq;

internal class Program
{
    private static void Main(string[] args)
    {
        Random rnd = new Random();


        string print(string txt)
        {
            while (true)
            {
                Console.WriteLine(txt);
                return Console.ReadLine();
            }

        }

        bool stop = true;


        Order order = new Order(rnd.Next(111, 999));
        while (stop)
        {
            string Name = print("Введите название бургера");
            decimal basePrice = Convert.ToDecimal(print("Введите цену бургера"));
            string ImagePath = print("Введите ссылку для картинки");
            Burger burger = new Burger(basePrice, Name, ImagePath);
            bool opt = Convert.ToBoolean(print("Хотите добавить дополнительные ингредиенты в бургер? (true/false)"));
            while (opt)
            {
                string nameOpt = print("Введите название опции");
                decimal priceOpt = Convert.ToDecimal(print("Введите цену"));
                opt = Convert.ToBoolean(print("Хотите добавить дополнительные ингредиенты в бургер? (true/false)"));
                Option option = new Option(nameOpt, priceOpt);
                burger.AddOption(option);
            }

            burger.BasePrice = burger.GetPrice();
            order.AppProduct(burger);
            burger.ClearOptions();
            stop = Convert.ToBoolean(print("Хотите добавить еще один бургер? (true/false)"));
        }
        stop = true;

        while (stop)
        {
            string Name = print("Введите название напитка");
            decimal basePrice = Convert.ToDecimal(print("Введите цену напитка"));
            string ImagePath = print("Введите ссылку для картинки");
            int volume = Convert.ToInt32(print("Введите обьем напитка"));
            bool IsBittled = Convert.ToBoolean(print("Напиток будет в большом обьеме? (true/false)"));
            Drink drink = new Drink(basePrice, Name, ImagePath, volume, IsBittled);

            drink.BasePrice = drink.GetPrice();
            order.AppProduct(drink);
            stop = Convert.ToBoolean(print("Хотите добавить еще один напиток? (true/false)"));
        }
        Console.WriteLine("Ваш заказ:");
        Console.WriteLine(order.GetCheck());
        Console.ReadLine();
    }
}